import { FormReader } from "./formReader.js";

const reader = new FormReader('form1');
const reader1 = new FormReader('form2');
